UKMO Fiche - Android Studio project
1) Android Studio > File > Open > choose this folder, wait for Gradle sync.
2) Build > Build Bundle(s) / APK(s) > Build APK(s).
App code: app/src/main/assets/index.html (web app), MainActivity.kt (WebView).
